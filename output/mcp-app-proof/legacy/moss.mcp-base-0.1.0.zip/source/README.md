# MCP 应用底座

Host API 3.9 的配置型 App 验证。基础 App 安装一次，派生应用按精确版本引用其公共 UI，页面通过 Host 绑定到派生应用身份。底座和派生应用都不运行注册用 Backend，Core 直接读取 MCP 声明。

构建：`node scripts/build.mjs`。首次构建从相邻 Moss Core 读取两个浏览器 SDK 模块；可用 `MOSS_CORE_ROOT` 指定路径。发布源码快照在 `src/sdk/` 携带这些模块，独立重建不依赖原工作区。

Draw.io 配置在 Apps 仓库的 `mcp-apps/drawio/`。Core 的 `scripts/generate-mcp-app.mjs` 生成只含声明和资源的应用，`scripts/verify-mcp-app.mjs` 打包并运行真实 Host 验证。
