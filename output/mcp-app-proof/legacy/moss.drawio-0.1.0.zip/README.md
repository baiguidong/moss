# Draw.io

使用官方 npm 包 `@drawio/mcp`，启动命令为 `npx -y @drawio/mcp`。首次启动需要联网下载，后续行为取决于 npx 缓存与上游版本。本验证保留用户指定的未锁版本命令。

在会话中选择 Draw.io 后，可以要求生成流程图、组织图和 Mermaid 图表。此 stdio 服务返回编辑器链接；它不是 draw.io 的网页内嵌 MCP Apps 服务。

应用代码全部来自 `moss.mcp-base@0.1.0`，本应用只有配置与资源。需要 Moss Host API 3.9。项目来源：https://github.com/jgraph/drawio-mcp 。图标为本配置提供的流程图示意图。
