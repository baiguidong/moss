import { createAppClient } from './sdk/ui/index.mjs'

const $ = selector => document.querySelector(selector)
const client = window.mossApp ? createAppClient(window.mossApp) : null
const labels = { connected: '已连接', failed: '连接失败', 'needs-auth': '需要授权', authorized: '已授权', unchecked: '尚未检查' }
let busy = false, disposed = false
const node = (tag, text, className) => { const element = document.createElement(tag); if (text) element.textContent = text; if (className) element.className = className; return element }
const message = (text, error = false) => { $('#message').textContent = text; $('#message').className = error ? 'error' : '' }
const request = (method, input = {}) => client.host.request('moss.mcp/v1', method, input, { timeoutMs: method === 'auth.start' ? 300_000 : 65_000 })
async function operation(work) {
  if (busy || disposed) return
  busy = true
  document.querySelectorAll('button,select,input').forEach(element => { element.disabled = true })
  try { await work() } catch (error) { message(error.message, true) }
  finally { busy = false; document.querySelectorAll('button,select,input').forEach(element => { element.disabled = false }) }
}
function render(catalog) {
  $('#servers').replaceChildren()
  for (const server of catalog.servers) {
    const card = node('section', '', 'server'), heading = node('div', '', 'server-heading')
    const state = !server.enabled ? 'disabled' : server.check?.state || 'unchecked'
    heading.append(node('h2', server.name), node('span', server.enabled ? labels[state] || state : '已停用', `status ${state}`))
    const config = server.config
    const command = config.type === 'stdio' ? [config.command, ...(config.args || [])].join('\n') : config.url
    card.append(heading, node('pre', command, 'command'))
    const actions = node('div', '', 'actions')
    const inspect = node('button', '检查连接')
    inspect.dataset.inspect = server.name
    inspect.onclick = () => operation(async () => { message('正在连接并发现工具…'); const result = await request('servers.inspect', { name: server.name }); render(result); report(result) })
    const enabled = node('input'); enabled.type = 'checkbox'; enabled.checked = server.enabled; enabled.setAttribute('aria-label', `启用 ${server.name}`)
    enabled.onchange = () => operation(async () => { render(await request('servers.set-enabled', { name: server.name, enabled: enabled.checked })); message('服务状态已更新。') })
    const label = node('label'); label.append(enabled, '启用服务'); actions.append(inspect, label)
    if (config.type !== 'stdio') {
      const auth = node('button', '浏览器授权')
      auth.onclick = () => operation(async () => { message('正在授权…'); render(await request('auth.start', { name: server.name })); message('授权完成，可检查连接。') })
      actions.append(auth)
    }
    card.append(actions)
    if (server.check?.error) card.append(node('p', server.check.error, 'error'))
    const tools = node('div', '', 'tools')
    tools.append(node('p', `可用工具 · ${server.check?.tools?.length || 0}`, 'muted'))
    for (const tool of server.check?.tools || []) {
      const row = node('details'); row.append(node('summary', tool.name + (tool.disabled ? '（已排除）' : '')), node('p', tool.description, 'tool-description')); tools.append(row)
    }
    if (server.check?.truncated) tools.append(node('p', '工具目录展示已截断。', 'muted'))
    card.append(tools)
    const editor = node('details'), input = node('textarea'); input.value = JSON.stringify(config, null, 2); input.setAttribute('aria-label', `${server.name} 连接配置`)
    const save = node('button', '保存配置')
    save.onclick = () => operation(async () => { render(await request('servers.save', { name: server.name, previousName: server.name, enabled: server.enabled, config: JSON.parse(input.value) })); message('配置已保存，可重新检查连接。') })
    editor.append(node('summary', '连接配置'), node('p', '密钥值不会显示。已有密钥字段留空会保留原值。', 'muted'), input, save); card.append(editor)
    $('#servers').append(card)
  }
}
function report(catalog) {
  const failed = catalog.servers.some(server => server.enabled && server.check?.state === 'failed')
  message(failed ? '连接未完成，请查看服务错误后重试。' : '服务状态已更新。', failed)
}
$('#refresh').onclick = () => operation(async () => { const catalog = await request('servers.list'); render(catalog); report(catalog) })
$('#scope').onchange = () => operation(async () => {
  const result = await client.host.request('moss.host/v1', 'tools.scope.set', { scope: $('#scope').value }); $('#scope').value = result.scope; message('工具使用范围已更新。')
})
window.addEventListener('pagehide', () => { disposed = true; client?.dispose() })
await operation(async () => {
  if (!client) throw new Error('请在 Moss 中打开此应用。')
  const [info, installation] = await Promise.all([client.app.getInfo(), client.app.getInstallationState()])
  $('#title').textContent = info.displayName; $('#description').textContent = info.description
  if (['dark', 'light'].includes(info.appearance?.theme)) document.documentElement.dataset.theme = info.appearance.theme
  $('.eyebrow').hidden = false
  if (installation?.manifest?.mcpAppBase) {
    $('.eyebrow').textContent = '共享组件'
    $('#base-info').hidden = false
    $('#message').hidden = true
    return
  }
  const [scope, catalog] = await Promise.all([client.host.request('moss.host/v1', 'tools.scope.get', {}), request('servers.list')])
  $('#refresh').hidden = false; $('.scope').hidden = false; $('#servers').hidden = false
  $('#scope').value = scope.scope
  render(catalog)
  message(catalog.servers.length ? '正在检查服务…' : '尚未配置服务。')
  for (const server of catalog.servers.filter(server => server.enabled && !server.check)) {
    const result = await request('servers.inspect', { name: server.name }); if (disposed) return; render(result); report(result)
  }
})
