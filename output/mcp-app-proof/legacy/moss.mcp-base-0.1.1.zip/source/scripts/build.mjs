import fs from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const root = fileURLToPath(new URL('..', import.meta.url))
const source = path.join(root, 'src'), output = path.join(root, 'dist/ui')
await fs.rm(output, { recursive: true, force: true })
await fs.cp(source, output, { recursive: true })
// Released source snapshots carry these two unchanged browser SDK modules.
if (!await fs.access(path.join(output, 'sdk/ui/index.mjs')).then(() => true, () => false)) {
  const core = process.env.MOSS_CORE_ROOT || path.resolve(root, '../../../moss')
  await fs.mkdir(path.join(output, 'sdk/ui'), { recursive: true })
  for (const name of ['ui/index.mjs', 'errors.mjs']) await fs.copyFile(path.join(core, 'packages/app-sdk/src', name), path.join(output, 'sdk', name))
}
