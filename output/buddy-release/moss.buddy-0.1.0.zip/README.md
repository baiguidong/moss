# Buddy 伴侣精灵

官方独立 App。给宠物取名并孵化后，可以和它真实聊天；选择小苔团、机器人或光球形象。宠物档案和历史保存在 App 私有目录，升级和换形象不会重置出生时间。

需要 Moss Host API 3.5 和可用的 Moss 模型配置。孵化本地完成；欢迎语为固定见面问候，后续回复经 `moss.agent/v1` 执行，失败会如实显示。内置行为规则随 App 发布，可在伙伴设置选择已有 Agent/助手。

配置能力经 `moss.settings/v1` 提供，包含 Desktop、Agent 用户/项目/本地、会话、App、MCP、助手规则和通用/终端偏好。目录返回实际支持的字段和目标；密钥通过相应凭据页面修改。当前没有远端 Server 管理 API 的字段不会被伪装成可修改。高影响修改由 Host 展示具体变更并确认；结果携带生效状态与撤销回执。

通知读取需要 `notifications:read`，已读状态与 Moss 通知中心同步。Agent 工具范围由绑定和 Host 授权共同约束。关闭配置功能后，App Backend 也拒绝写入；不仅隐藏 UI。

```sh
bun run check
bun run test
bun run build
```

发布包通过仓库打包工具生成，包含源码与 checksums；市场发布还需发布者签名。App 随 Moss 进程运行，退出 Moss 后不继续服务。
