# moss.buddy source

App edit root: apps/buddy

Toolchain: bun@1.3.10; Node 25.7.0.

From this directory run `bun install --frozen-lockfile`, then in `apps/buddy` run `bun run check`, `bun run test`, and `bun run build`.

Desktop/Host/browser integration scripts may require a complete Core checkout, browser binaries or explicit test configuration. Those external integrations are separate from the included business tests. Dependencies are downloaded from the pinned lockfile; no original workspace or source cache is needed.
