import {test} from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs/promises'
import os from 'node:os'
import path from 'node:path'
import {createBuddyController} from '../src/backend/controller.mjs'

async function fixture(t){
 const dataDir=await fs.mkdtemp(path.join(os.tmpdir(),'moss-buddy-'));t.after(()=>fs.rm(dataDir,{recursive:true,force:true}))
 const calls=[],turns=[];let binding=null
 const host=async(protocol,method,input)=>{
  calls.push({protocol,method,input})
  if(method==='binding.get')return {binding}
  if(method==='binding.update'){binding={...input.patch,revision:(binding?.revision||0)+1};return {binding}}
  if(method==='turn.start'){let turn=turns.find(t=>t.externalEventId===input.externalEventId);if(!turn){turn={id:`turn-${turns.length}`,status:'queued',externalEventId:input.externalEventId};turns.push(turn)};return {turnId:turn.id,status:turn.status}}
  if(method==='turn.get')return {turn:turns.find(t=>t.id===input.turnId)}
  if(method==='turn.list')return {turns}
  if(method==='turn.abort'){turns.find(t=>t.id===input.turnId).status='cancelled';return {}}
  if(method==='turn.delivery.ack')return {}
  if(method==='catalog.list')return {agents:[],tools:[]}
  if(method==='catalog')return {domains:[]}
  return {status:'saved'}
 }
 const make=()=>createBuddyController({dataDir,host,instructions:'Buddy instructions',handbook:[]})
 const controller=await make()
 return {dataDir,calls,turns,controller,restart:make,host}
}
test('hatch is local/idempotent; appearance and name changes retain birthday, identity and chat',async t=>{
 const f=await fixture(t),a=f.controller.actions
 const born=await a['pet.hatch']({name:'苔苔',skin:'robot'});assert.equal(f.calls.length,0)
 assert.deepEqual(await a['pet.hatch']({name:'another'}),born)
 const changed=await a['pet.update']({revision:born.revision,name:'小苔',skin:'orb'})
 assert.equal(changed.pet.id,born.pet.id);assert.equal(changed.pet.hatchedAt,born.pet.hatchedAt);assert.deepEqual(changed.messages,born.messages)
 const restarted=await f.restart();assert.deepEqual(await restarted.actions['pet.get'](),changed)
})
test('real Host turns bind the default assistant, deduplicate replies and keep conversation across sends',async t=>{
 const f=await fixture(t),a=f.controller.actions;await a['pet.hatch']({})
 const first=await a['chat.send']({text:'你好',requestId:'first'});assert.equal(first.pending.length,1)
 await a['chat.send']({text:'你好',requestId:'first'});assert.equal(f.turns.length,1)
 assert.ok(f.calls.find(c=>c.method==='binding.update').input.patch.resources.tools.includes('app__moss_buddy__settings_apply'))
 f.turns[0].status='completed';f.turns[0].resultText='模型的真实返回'
 await f.controller.onTurn(f.turns[0].id);await f.controller.onTurn(f.turns[0].id)
 const result=await a['pet.get']();assert.equal(result.messages.filter(m=>m.role==='assistant').length,1);assert.equal(result.messages.at(-1).text,'模型的真实返回');assert.equal(result.pending.length,0)
 await a['chat.send']({text:'你记得刚才吗',requestId:'second'})
 const starts=f.calls.filter(c=>c.method==='turn.start');assert.equal(starts[0].input.externalConversationId,starts[1].input.externalConversationId)
})
test('reconciles an accepted turn after a crash before persisting its id',async t=>{
 const f=await fixture(t),a=f.controller.actions;await a['pet.hatch']({});await a['chat.send']({text:'hi',requestId:'request'})
 const file=path.join(f.dataDir,'buddy.json'),data=JSON.parse(await fs.readFile(file,'utf8'));delete data.requests.request.turnId;data.requests.request.status='sending';await fs.writeFile(file,JSON.stringify(data))
 f.turns[0].status='completed';f.turns[0].resultText='recovered'
 const restarted=await f.restart(),result=await restarted.actions['pet.get']();assert.equal(result.pending.length,0);assert.equal(result.messages.at(-1).text,'recovered');assert.equal(f.turns.length,1)
})
test('legacy migration retains birthday and cannot overwrite an existing pet',async t=>{
 const f=await fixture(t),a=f.controller.actions;const imported=await a['pet.import-legacy']({name:'老伙伴',personality:'好奇',hatchedAt:123456789,userId:'old-id'})
 assert.equal(imported.pet.hatchedAt,123456789)
 assert.deepEqual(await a['pet.import-legacy']({name:'wrong',hatchedAt:1}),imported)
})
test('disabled configuration is enforced by the backend and cancelled turns can send again',async t=>{
 const f=await fixture(t),a=f.controller.actions;const state=await a['pet.hatch']({})
 await a['pet.update']({revision:state.revision,preferences:{configEnabled:false,tools:['Read']}})
 assert.throws(()=>a.settings_apply({}),/关闭/);assert.throws(()=>a.settings_undo({}),/关闭/)
 await a['chat.send']({text:'hello',requestId:'one'})
 const bound=f.calls.find(c=>c.method==='binding.update').input.patch;assert.ok(bound.resources.tools.includes('Read'));assert.ok(!bound.resources.tools.includes('app__moss_buddy__settings_apply'))
 assert.equal((await a['chat.stop']()).pending.length,0);await a['chat.send']({text:'again',requestId:'two'});assert.equal(f.turns.length,2)
})
